package com.anilili.data

import com.anilili.data.library.HistoryEntry
import com.anilili.data.library.WatchlistEntry
import com.anilili.data.library.mediaListStatusLabel
import com.anilili.data.library.mergeWatchlistEntries
import com.anilili.data.library.remoteListStatuses
import com.anilili.data.library.sortHistoryLatestFirst
import com.anilili.data.model.Media
import com.anilili.data.model.MediaListEntry
import com.anilili.data.model.MediaRelationConnection
import com.anilili.data.model.MediaRelationEdge
import com.anilili.data.model.MediaTag
import com.anilili.data.model.contentAdvisory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreModelsTest {
    @Test
    fun `anime display titles prefer english over AniList viewer preference`() {
        val title = com.anilili.data.model.MediaTitle(
            english = "Attack on Titan",
            userPreferred = "Shingeki no Kyojin",
            romaji = "Shingeki no Kyojin",
        )
        assertEquals("Attack on Titan", title.preferred)
    }

    @Test
    fun historyProgressIsBoundedAndEpisodeLabelIsFriendly() {
        val entry = HistoryEntry(
            anilistId = 1,
            title = "Test",
            cover = null,
            episodeNumber = 3.0,
            provider = "bonk",
            category = "sub",
            positionMs = 75_000,
            durationMs = 100_000,
        )

        assertEquals("3", entry.episodeLabel)
        assertEquals(.75f, entry.progressFraction)
        assertTrue(entry.copy(positionMs = 200_000).progressFraction <= 1f)
    }

    @Test
    fun watchHistoryIsSortedWithLatestPlaybackFirst() {
        val entries = listOf(
            HistoryEntry(1, "Earliest", null, 1.0, provider = "bonk", category = "sub", updatedAt = 100),
            HistoryEntry(2, "Latest", null, 2.0, provider = "bonk", category = "sub", updatedAt = 300),
            HistoryEntry(3, "Middle", null, 3.0, provider = "bonk", category = "sub", updatedAt = 200),
        )

        assertEquals(listOf(2, 3, 1), sortHistoryLatestFirst(entries).map(HistoryEntry::anilistId))
    }

    @Test
    fun providerCatalogKeepsKnownMiruroProvidersAheadOfNativeFallbacks() {
        assertTrue(ProviderCatalog.sortKey("bonk") < ProviderCatalog.sortKey("allanime"))
        assertEquals("Bonk", ProviderCatalog.label("bonk"))
        assertTrue(ProviderCatalog.supportsExternalDownloads("bonk"))
        assertTrue(ProviderCatalog.supportsExternalDownloads("kiwi"))
    }

    /**
     * Where an embed the app can resolve natively belongs in the picker.
     *
     * `twin`'s page hands over plain HLS to one OkHttp GET, so it stopped paying the cost that put
     * every embed at the back — a WebView, and with it no app controls, no Cast, no downloads. It
     * therefore sorts with the fast servers rather than with the embeds it no longer resembles.
     *
     * The two bounds are what make that a rank rather than a promotion. It stays *behind* `bonk`,
     * the provider it re-hosts, because reaching a source directly should always beat reaching a
     * copy of it. It stays *ahead* of `nun`/`bun`/`cog`/`telli`, which are still WebView-only.
     * Relations are asserted rather than positions so that reordering upstream — `miruroOrder` is
     * copied from Miruro's own `providerOrder` — does not have to be mirrored here.
     */
    @Test
    fun providerCatalogRanksAResolvableEmbedWithTheFastServers() {
        assertTrue(ProviderCatalog.isFast("twin"))
        assertFalse(ProviderCatalog.isFast("nun"))

        assertTrue(ProviderCatalog.sortKey("bonk") < ProviderCatalog.sortKey("twin"))
        for (embed in listOf("nun", "bun", "cog", "telli")) {
            assertTrue(embed, ProviderCatalog.sortKey("twin") < ProviderCatalog.sortKey(embed))
        }
        // And ahead of the full-page scrapers, which is the point of the badge.
        assertTrue(ProviderCatalog.sortKey("twin") < ProviderCatalog.sortKey("animegg"))
    }

    @Test
    fun contentAdvisoryUsesProminentNonSpoilerTagsAndAdultFlag() {
        val advisory = Media(
            id = 7,
            isAdult = true,
            tags = listOf(
                MediaTag("Gore", rank = 70),
                MediaTag("Profanity", rank = 60),
                MediaTag("Torture", rank = 90, isMediaSpoiler = true),
                MediaTag("Nudity", rank = 20),
            ),
        ).contentAdvisory()

        assertTrue(advisory.isAdult)
        assertEquals(listOf("Violence", "Sexual content", "Strong language", "Mature themes"), advisory.labels)
    }

    @Test
    fun planningHydrationPreservesLocalEntriesAndRefreshesSharedMetadata() {
        val local = listOf(
            WatchlistEntry(1, "Local title", null, addedAt = 10),
            WatchlistEntry(2, "Device only", null, addedAt = 20),
        )
        val remote = listOf(
            WatchlistEntry(1, "AniList title", "cover"),
            WatchlistEntry(3, "Remote only", null),
        )

        val merged = mergeWatchlistEntries(local, remote, addedAt = 99)

        assertEquals(listOf(1, 2, 3), merged.map { it.anilistId })
        assertEquals("AniList title", merged.first().title)
        assertEquals(10, merged.first().addedAt)
        assertEquals(99, merged.last().addedAt)
    }

    @Test
    fun remoteLibrarySnapshotKeepsEveryAniListStatusForDetailPages() {
        val statuses = remoteListStatuses(
            listOf(
                MediaListEntry(status = "CURRENT", media = Media(id = 1)),
                MediaListEntry(status = "PLANNING", media = Media(id = 2)),
                MediaListEntry(status = "COMPLETED", media = Media(id = 3)),
            ),
        )

        assertEquals(mapOf(1 to "CURRENT", 2 to "PLANNING", 3 to "COMPLETED"), statuses)
        assertEquals("Watching", mediaListStatusLabel(statuses[1]))
        assertEquals("Plan to watch", mediaListStatusLabel(statuses[2]))
        assertEquals("Completed", mediaListStatusLabel(statuses[3]))
    }

    @Test
    fun seasonNeighborsKeepsOnlyUniquePrequelsAndSequels() {
        val previous = Media(id = 1)
        val sideStory = Media(id = 2)
        val next = Media(id = 3)
        val root = Media(
            id = 10,
            relations = MediaRelationConnection(
                listOf(
                    MediaRelationEdge("PREQUEL", previous),
                    MediaRelationEdge("SIDE_STORY", sideStory),
                    MediaRelationEdge("SEQUEL", next),
                    MediaRelationEdge("SEQUEL", next),
                ),
            ),
        )

        assertEquals(listOf(1, 3), root.seasonNeighbors().map(Media::id))
    }
}
