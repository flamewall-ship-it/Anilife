package com.anilili.data.remote

import com.anilili.data.model.Media
import com.anilili.data.model.SourcesResult
import com.anilili.data.model.StreamItem
import com.anilili.data.model.SubtitleItem
import com.anilili.diagnostics.DiagnosticsLog
import com.anilili.util.Base64Compat
import com.anilili.util.cached
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

internal class AllAnimeProvider(
    private val client: OkHttpClient,
    private val json: Json,
    private val protocol: AllAnimeProtocolVersion = AllAnimeProtocolConfig.active,
    private val currentRouteGuard: AllAnimeCurrentRouteGuard = AllAnimeCurrentRouteGuard(),
    private val endpointOutageGuard: AllAnimeEndpointOutageGuard = AllAnimeEndpointOutageGuard(),
    buildStore: AllAnimeBuildStore = AllAnimeBuildStore.memory(),
    private val captchaRequester: suspend (String) -> AllAnimeCaptchaSolution? = AllAnimeCaptchaCoordinator::request,
) {
    internal enum class SourceRoute { CURRENT, LEGACY }

    private data class SourcePayload(
        val sources: List<AllAnimeCodec.Source>,
        val subtitles: List<SubtitleItem>,
        val route: SourceRoute,
    )

    internal data class ClockResult(
        val streams: List<StreamItem>,
        val subtitles: List<SubtitleItem>,
    )

    private class CurrentRouteRateLimit(message: String) : IllegalStateException(message)
    private class CurrentRouteCryptoError(message: String) : IllegalStateException(message)
    private data class RouteError(val message: String, val needsCaptcha: Boolean, val cryptoFailure: Boolean)

    private data class Candidate(
        val id: String,
        val title: String,
        val englishTitle: String?,
        val malId: Int?,
        val availableSub: Int,
        val availableDub: Int,
    )

    private val showIds = ConcurrentHashMap<Int, String>()
    private val keyManager = AllAnimeKeyManager(client, json, protocol, buildStore)
    private val externalExtractor = AllAnimeExternalExtractor(client, json)
    @Volatile
    internal var lastSourceRoute: SourceRoute? = null
        private set

    fun episodeAvailability(media: Media): EpisodeAvailability {
        val candidate = resolveCandidate(media, "sub")
        showIds[media.id] = candidate.id
        return EpisodeAvailability.counts(candidate.availableSub, candidate.availableDub)
    }

    fun sources(media: Media, audio: String, episode: Int): SourcesResult {
        return sources(media, audio, episode, allowLegacyFallback = true)
    }

    /** Interactive playback path. Background catalog/source probes deliberately use [sources]. */
    suspend fun sourcesInteractive(media: Media, audio: String, episode: Int): SourcesResult {
        val showId = withContext(Dispatchers.IO) {
            showIds[media.id] ?: resolveShow(media, audio).also { showIds[media.id] = it }
        }
        return sourcesForShowInteractive(showId, audio, episode)
    }

    internal suspend fun sourcesForShowInteractive(
        showId: String,
        audio: String,
        episode: Int,
    ): SourcesResult {
        val payload = try {
            withContext(Dispatchers.IO) { fetchSourcePayload(showId, audio, episode, allowLegacyFallback = true) }
        } catch (required: AllAnimeCaptchaRequiredException) {
            if (!required.currentRoute) throw required
            val solution = captchaRequester("${protocol.currentApiOrigin}/captcha/turnstile")
                ?: throw IllegalStateException("AllAnime security check was cancelled")
            withContext(Dispatchers.IO) {
                DiagnosticsLog.event("AllAnime CAPTCHA retry start provider=${solution.provider}")
                fetchCurrentSourcePayload(showId, audio, episode, solution).also {
                    currentRouteGuard.recordSuccess()
                    DiagnosticsLog.event("AllAnime CAPTCHA retry succeeded")
                }
            }
        }
        return withContext(Dispatchers.IO) { sourcesFromPayload(payload, audio, episode) }
    }

    internal fun sources(
        media: Media,
        audio: String,
        episode: Int,
        allowLegacyFallback: Boolean,
    ): SourcesResult {
        val showId = showIds[media.id] ?: resolveShow(media, audio).also { showIds[media.id] = it }
        return sourcesForShow(showId, audio, episode, allowLegacyFallback)
    }

    internal fun sourcesForShow(
        showId: String,
        audio: String,
        episode: Int,
        allowLegacyFallback: Boolean = true,
    ): SourcesResult {
        val payload = fetchSourcePayload(showId, audio, episode, allowLegacyFallback)
        return sourcesFromPayload(payload, audio, episode)
    }

    private fun sourcesFromPayload(payload: SourcePayload, audio: String, episode: Int): SourcesResult {
        lastSourceRoute = payload.route
        val native = mutableListOf<StreamItem>()
        val embeds = mutableListOf<StreamItem>()
        val subtitles = payload.subtitles.toMutableList()

        payload.sources.sortedByDescending(AllAnimeCodec.Source::priority).forEach { source ->
            if (source.name.equals("Ss-Hls", true)) return@forEach
            val rawUrl = AllAnimeCodec.decodeSourceUrl(source.url)
            if (AllAnimeCodec.isEncodedSource(source.url)) {
                if (rawUrl.contains("/clock") || rawUrl.startsWith("/apivtwo/")) {
                    val clock = resolveClock(rawUrl, audio, source.name)
                    native += clock.streams
                    subtitles += clock.subtitles
                }
                return@forEach
            }
            if (!rawUrl.startsWith("http://") && !rawUrl.startsWith("https://")) return@forEach

            if (externalExtractor.supports(rawUrl)) {
                val extracted = externalExtractor.resolve(rawUrl, source.name, audio)
                if (extracted.isNotEmpty()) {
                    native += extracted
                } else {
                    // Preserve playback when a third-party host rotates its page protection. The
                    // visible embed can execute that host's current JavaScript while the native
                    // resolver is updated independently.
                    embeds += stream(
                        rawUrl,
                        "embed",
                        source.name.ifBlank { "MKissa embed" },
                        audio,
                        protocol.playerReferer,
                    )
                }
                return@forEach
            }

            val isDirect = MEDIA_URL.containsMatchIn(rawUrl) ||
                (source.type.equals("player", true) && !HTML_PLAYER_URL.containsMatchIn(rawUrl)) ||
                source.fileExtension.equals("mp4", true) || source.fileExtension.equals("m3u8", true)
            if (isDirect) {
                val type = if (rawUrl.contains(".m3u8", true) || source.fileExtension.equals("m3u8", true)) "hls" else "mp4"
                native += stream(rawUrl, type, qualityLabel(source.name, source.quality), audio, protocol.playerReferer)
            } else {
                embeds += stream(rawUrl, "embed", source.name.ifBlank { "MKissa embed" }, audio, protocol.playerReferer)
            }
        }

        val verified = native.distinctBy(StreamItem::url).filter(::isPlayable)
        val streams = (verified + embeds.distinctBy(StreamItem::url)).mapIndexed { index, item ->
            item.copy(isActive = index == 0)
        }
        if (streams.isEmpty()) error("AllAnime episode $episode has no playable sources")
        return SourcesResult(
            streams,
            subtitles.map(::absoluteSubtitle).distinctBy(SubtitleItem::url),
            null,
            null,
        )
    }

    private fun resolveShow(media: Media, audio: String): String {
        return resolveCandidate(media, audio).id
    }

    private fun resolveCandidate(media: Media, audio: String): Candidate {
        val candidates = titles(media).flatMap { title ->
            runCatching {
                retryOnce("AllAnime title search query=${title.take(80)}") {
                    search(title, audio, media.isAdult)
                }
            }.onFailure {
                logFailure("AllAnime title search failed query=${title.take(80)}", it)
            }.getOrDefault(emptyList())
        }.distinctBy(Candidate::id)
        media.idMal?.let { malId -> candidates.firstOrNull { it.malId == malId }?.let { return it } }

        // A title match may only pick a show that is not known to be a different one. Aware!
        // Meisaku-kun (2026) — MAL 63219, 12 episodes — was matched to the 2016 series, MAL 32956,
        // 230 episodes, because "(2026)" costs little in a title score and the site did not carry
        // the new season: its episode 11 was offered and played as the 2026 one. A sequel that
        // shares its predecessor's name is exactly the case a title score cannot settle and a MAL
        // id can, so a candidate carrying a different id is dropped rather than outscored.
        val matchable = candidates.filter { malIdsAgree(it.malId, media.idMal) }
        val chosen = matchable.maxByOrNull { candidate ->
            titles(media).maxOfOrNull { title ->
                maxOf(
                    NativeProviderParsers.titleScore(title, candidate.title),
                    NativeProviderParsers.titleScore(title, candidate.englishTitle.orEmpty()),
                )
            } ?: 0.0
        } ?: error("AllAnime match not found")
        val score = titles(media).maxOfOrNull { title ->
            maxOf(
                NativeProviderParsers.titleScore(title, chosen.title),
                NativeProviderParsers.titleScore(title, chosen.englishTitle.orEmpty()),
            )
        } ?: 0.0
        if (score < 0.35) error("AllAnime title match was too weak")
        return chosen
    }

    private fun search(query: String, audio: String, allowAdult: Boolean): List<Candidate> {
        val variables = buildJsonObject {
            putJsonObject("search") {
                put("allowAdult", allowAdult)
                put("allowUnknown", false)
                put("query", query)
            }
            put("limit", 20)
            put("page", 1)
            put("translationType", if (audio == "dub") "dub" else "sub")
            put("countryOrigin", "ALL")
        }
        val root = postGraphQl(SEARCH_QUERY, variables)
        val edges = (((root["data"] as? JsonObject)?.get("shows") as? JsonObject)?.get("edges") as? JsonArray)
            .orEmpty()
        return edges.mapNotNull { element ->
            val item = element as? JsonObject ?: return@mapNotNull null
            val id = item.string("_id") ?: return@mapNotNull null
            Candidate(
                id = id,
                title = item.string("name") ?: id,
                englishTitle = item.string("englishName"),
                malId = item.int("malId"),
                availableSub = ((item["availableEpisodes"] as? JsonObject)?.int("sub") ?: 0),
                availableDub = ((item["availableEpisodes"] as? JsonObject)?.int("dub") ?: 0),
            )
        }
    }

    private fun postGraphQl(query: String, variables: JsonObject): JsonObject {
        val body = buildJsonObject {
            put("query", query)
            put("variables", variables)
        }.toString().toRequestBody(JSON_MEDIA_TYPE)
        val current = attemptCatalogRoute(protocol.currentApi, body)
        current.getOrNull()?.let { return it }

        logFailure("MKissa current catalog route failed; trying legacy AllAnime", current.exceptionOrNull()!!)
        return attemptCatalogRoute(protocol.legacyApi, body).getOrThrow()
    }

    /** One catalog endpoint, skipped outright while it is cooling down from a 5xx. */
    private fun attemptCatalogRoute(url: String, body: okhttp3.RequestBody): Result<JsonObject> {
        if (!endpointOutageGuard.shouldAttempt(url)) {
            return Result.failure(
                IllegalStateException("AllAnime catalog route is cooling down after an outage"),
            )
        }
        return runCatching { postCatalogGraphQl(url, body) }
            .onSuccess { endpointOutageGuard.recordSuccess(url) }
            .onFailure { failure ->
                if (endpointOutageGuard.recordFailure(url, failure)) {
                    val host = runCatching { url.toHttpUrl().host }.getOrDefault("unknown")
                    logFailure("AllAnime catalog route on $host cooling down after an outage", failure)
                }
            }
    }

    private fun postCatalogGraphQl(url: String, body: okhttp3.RequestBody): JsonObject {
        val request = Request.Builder().url(url).post(body).allAnimeHeaders().build()
        val root = executeText(request).let(json::parseToJsonElement) as? JsonObject
            ?: error("MKissa returned invalid catalog data")
        currentRouteError(root)?.let { routeError ->
            error("MKissa catalog route error: ${routeError.message.take(240)}")
        }
        return root
    }

    private fun fetchSourcePayload(
        showId: String,
        audio: String,
        episode: Int,
        allowLegacyFallback: Boolean,
    ): SourcePayload {
        if (!currentRouteGuard.shouldAttempt()) {
            val suppressed = IllegalStateException(
                "AllAnime current route temporarily suppressed after a protocol mismatch",
            )
            logFailure(
                "AllAnime ${protocol.version} current route skipped show=$showId audio=$audio episode=$episode" +
                    if (allowLegacyFallback) "; using legacy" else "; legacy disabled",
                suppressed,
            )
            if (!allowLegacyFallback) throw suppressed
            return fetchLegacySourcePayload(showId, audio, episode)
        }

        val current = runCatching {
            retryCurrentRoute("AllAnime ${protocol.version} current source route") {
                fetchCurrentSourcePayload(showId, audio, episode)
            }
        }
        current.getOrNull()?.takeIf { it.sources.isNotEmpty() }?.let {
            currentRouteGuard.recordSuccess()
            return it
        }

        val currentFailure = current.exceptionOrNull()
            ?: IllegalStateException("AllAnime current source route returned no sources")
        // CAPTCHA is a valid upstream response, not a protocol mismatch and not a reason to make
        // the same unauthenticated request against the legacy host.
        if (currentFailure is AllAnimeCaptchaRequiredException) throw currentFailure
        if (currentRouteGuard.recordFailure(currentFailure)) {
            logFailure(
                "AllAnime ${protocol.version} current route disabled temporarily after protocol mismatch",
                currentFailure,
            )
        }
        logFailure(
            "AllAnime ${protocol.version} current route failed show=$showId audio=$audio episode=$episode" +
                if (allowLegacyFallback) "; trying legacy" else "; legacy disabled",
            currentFailure,
        )
        if (!allowLegacyFallback) throw currentFailure
        return fetchLegacySourcePayload(showId, audio, episode)
    }

    private fun fetchCurrentSourcePayload(
        showId: String,
        audio: String,
        episode: Int,
        captcha: AllAnimeCaptchaSolution? = null,
    ): SourcePayload {
        var lastCryptoError: Throwable? = null
        repeat(MAX_KEY_ATTEMPTS) { attempt ->
            val material = keyManager.material(forceRefresh = attempt > 0)
            try {
                return fetchCurrentSourcePayloadOnce(showId, audio, episode, captcha, material)
            } catch (error: CurrentRouteCryptoError) {
                lastCryptoError = error
                keyManager.invalidate(clearBuild = attempt >= 1)
                logFailure("AllAnime current crypto rejected attempt=${attempt + 1}", error)
            }
        }
        throw lastCryptoError ?: IllegalStateException("AllAnime current crypto failed")
    }

    private fun fetchCurrentSourcePayloadOnce(
        showId: String,
        audio: String,
        episode: Int,
        captcha: AllAnimeCaptchaSolution?,
        material: AllAnimeKeyManager.Material,
    ): SourcePayload {
        val aaReq = AllAnimeMkissaCrypto.signRequest(
            key = material.key,
            epoch = material.epoch,
            buildId = material.buildId,
            queryHash = protocol.currentSourcesHash,
            lane = protocol.contentLane,
        )
        val variables = buildJsonObject {
            put("showId", showId)
            put("translationType", if (audio == "dub") "dub" else "sub")
            put("episodeString", episode.toString())
        }
        val extensions = buildJsonObject {
            putJsonObject("persistedQuery") {
                put("version", 1)
                put("sha256Hash", protocol.currentSourcesHash)
            }
            put("k", protocol.contentLane)
            put("aaReq", aaReq)
            captcha?.let { solution ->
                putJsonObject("captcha") {
                    put("token", solution.token)
                    put("provider", solution.provider)
                }
            }
        }
        val request = if (captcha == null) {
            val url = protocol.currentApi.toHttpUrl().newBuilder()
                .addQueryParameter("variables", variables.toString())
                .addQueryParameter("extensions", extensions.toString())
                .build()
            Request.Builder().url(url).get().currentApiHeaders(material.buildId).build()
        } else {
            // Keep the short-lived challenge token out of URLs, logs, caches, and browser history.
            val body = buildJsonObject {
                put("variables", variables)
                put("extensions", extensions)
            }.toString().toRequestBody(JSON_MEDIA_TYPE)
            Request.Builder()
                .url(protocol.currentApi)
                .post(body)
                .currentApiHeaders(material.buildId)
                .header("Content-Type", "application/json")
                .build()
        }
        val root = json.parseToJsonElement(executeText(request)) as? JsonObject
            ?: error("AllAnime returned invalid source data")
        currentRouteError(root)?.let { error ->
            val message = error.message
            if (error.needsCaptcha) throw AllAnimeCaptchaRequiredException(currentRoute = true)
            if (error.cryptoFailure) throw CurrentRouteCryptoError(message)
            if (message.contains("too many requests", true)) {
                throw CurrentRouteRateLimit(message)
            }
            error("AllAnime current route error: ${message.take(240)}")
        }
        val data = root["data"] as? JsonObject ?: error("AllAnime returned no source data")
        val encrypted = data.string("tobeparsed")
        val decoded = if (!encrypted.isNullOrBlank()) {
            AllAnimeMkissaCrypto.decrypt(encrypted, material.key)
                ?.let(json::parseToJsonElement)
                ?: throw CurrentRouteCryptoError("AllAnime current response could not be decrypted")
        } else {
            data["episode"] ?: error("AllAnime current source payload missing")
        }
        val sources = AllAnimeCodec.parseSources(decoded)
        if (sources.isEmpty()) {
            error(
                "AllAnime current source payload empty show=$showId audio=$audio episode=$episode " +
                    "keys=${(decoded as? JsonObject)?.keys.orEmpty().sorted()}",
            )
        }
        return SourcePayload(
            sources = sources,
            subtitles = AllAnimeCodec.parseSubtitles(decoded),
            route = SourceRoute.CURRENT,
        )
    }

    private fun fetchLegacySourcePayload(showId: String, audio: String, episode: Int): SourcePayload {
        val variables = buildJsonObject {
            put("showId", showId)
            put("translationType", if (audio == "dub") "dub" else "sub")
            put("episodeString", episode.toString())
        }
        val extensions = buildJsonObject {
            putJsonObject("persistedQuery") {
                put("version", 1)
                put("sha256Hash", protocol.legacySourcesHash)
            }
        }
        val url = protocol.legacyApi.toHttpUrl().newBuilder()
            .addQueryParameter("variables", variables.toString())
            .addQueryParameter("extensions", extensions.toString())
            .build()
        val root = json.parseToJsonElement(
            executeText(Request.Builder().url(url).get().allAnimeHeaders().build()),
        ) as? JsonObject ?: error("AllAnime returned invalid legacy source data")
        currentRouteError(root)?.let { error ->
            if (error.needsCaptcha) throw AllAnimeCaptchaRequiredException(currentRoute = false)
            throw IllegalStateException("AllAnime legacy route error: ${error.message.take(240)}")
        }
        val data = root["data"] as? JsonObject ?: error("AllAnime returned no legacy source data")
        val decoded = data.string("tobeparsed")?.takeIf(String::isNotBlank)?.let(AllAnimeCodec::decrypt)
            ?: data["episode"]
        return SourcePayload(
            sources = AllAnimeCodec.parseSources(decoded),
            subtitles = AllAnimeCodec.parseSubtitles(decoded),
            route = SourceRoute.LEGACY,
        )
    }

    internal fun resolveClock(path: String, audio: String, fallbackName: String): ClockResult {
        val playerOrigin = protocol.playerReferer.removeSuffix("/")
        val url = NativeProviderParsers.absoluteUrl(playerOrigin, path)
        val request = Request.Builder().url(url).get().playerHeaders().build()
        val root = runCatching { json.parseToJsonElement(executeText(request)) as? JsonObject }.getOrNull()
            ?: return ClockResult(emptyList(), emptyList())
        val streams = (root["links"] as? JsonArray).orEmpty().flatMap { element ->
            val link = element as? JsonObject ?: return@flatMap emptyList()
            buildList {
                val streamUrl = link.string("link") ?: link.string("url")
                if (!streamUrl.isNullOrBlank()) {
                    val hls = link.boolean("hls") || streamUrl.contains(".m3u8", true) ||
                        streamUrl.contains("repackager.wixmp", true)
                    val dash = link.boolean("dash") && streamUrl.contains(".mpd", true)
                    add(
                        stream(
                            streamUrl,
                            when {
                                hls -> "hls"
                                dash -> "dash"
                                else -> "mp4"
                            },
                            qualityLabel(fallbackName, link.string("resolutionStr")),
                            audio,
                            protocol.playerReferer,
                        ),
                    )
                }
                val portStreams = (((link["portData"] as? JsonObject)?.get("streams")) as? JsonArray).orEmpty()
                portStreams.forEach { portElement ->
                    val port = portElement as? JsonObject ?: return@forEach
                    val portUrl = port.string("url") ?: return@forEach
                    val format = port.string("format").orEmpty()
                    val type = when {
                        format == "adaptive_hls" || portUrl.contains(".m3u8", true) -> "hls"
                        format == "adaptive_dash" || portUrl.contains(".mpd", true) -> "dash"
                        else -> null
                    }
                    if (type != null) {
                        add(
                            stream(
                                portUrl,
                                type,
                                qualityLabel(fallbackName, link.string("resolutionStr")),
                                audio,
                                protocol.playerReferer,
                            ),
                        )
                    }
                }
            }
        }
        return ClockResult(streams, AllAnimeCodec.parseSubtitles(root))
    }

    internal fun isPlayable(item: StreamItem): Boolean = runCatching {
        val builder = Request.Builder()
            .url(item.url)
            .header("User-Agent", ALLANIME_USER_AGENT)
            .header("Referer", item.referer ?: protocol.playerReferer)
        item.headers.forEach(builder::header)
        if (!item.isHls) builder.header("Range", "bytes=0-1")
        client.newCall(builder.get().build()).execute().use { response ->
            if (!response.isSuccessful && response.code != 206) return@use false
            val contentType = response.header("Content-Type").orEmpty().lowercase()
            if ("text/html" in contentType) return@use false
            if (!item.isHls) return@use true
            response.body?.string().orEmpty().trimStart().startsWith("#EXTM3U")
        }
    }.onFailure {
        val host = item.url.substringAfter("://", item.url).substringBefore('/').take(120)
        logFailure("AllAnime direct stream probe failed host=$host", it)
    }.getOrDefault(false)

    private fun executeText(request: Request): String = client.newCall(request).execute().use { response ->
        val body = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            throw AllAnimeHttpException(response.code, body.take(MAX_ERROR_BODY_CHARS))
        }
        body
    }

    private fun Request.Builder.allAnimeHeaders(): Request.Builder = this
        .header("User-Agent", ALLANIME_USER_AGENT)
        .header("Referer", protocol.apiReferer)
        .header("Origin", protocol.apiOrigin)
        .header("Accept", "application/json, */*")

    private fun Request.Builder.currentApiHeaders(buildId: String): Request.Builder = this
        .header("User-Agent", ALLANIME_USER_AGENT)
        .header("Origin", protocol.siteUrl)
        .header("Referer", protocol.currentReferer)
        .header("Accept", "application/json, */*")
        .header("x-build-id", buildId)

    private fun Request.Builder.playerHeaders(): Request.Builder = this
        .header("User-Agent", ALLANIME_USER_AGENT)
        .header("Referer", protocol.playerReferer)
        .header("Accept", "application/json, */*")

    private fun absoluteSubtitle(item: SubtitleItem): SubtitleItem = item.copy(
        url = NativeProviderParsers.absoluteUrl(protocol.playerReferer, item.url),
    )

    private fun logFailure(message: String, throwable: Throwable) {
        // Local JVM tests use Android stubs, so logging itself must never alter provider behavior.
        runCatching { DiagnosticsLog.throwable(message, throwable) }
    }

    private inline fun <T> retryOnce(label: String, block: () -> T): T {
        return runCatching(block).getOrElse { firstFailure ->
            // A rate-limited request already consumed the server's burst allowance. Production
            // should fall back immediately; live tests space requests before reaching this point.
            if (firstFailure is CurrentRouteRateLimit) throw firstFailure
            // Same reasoning for an outage: the host answered 5xx, and asking it again a
            // millisecond later only doubles the requests aimed at something already down.
            if (isUpstreamOutage(firstFailure)) throw firstFailure
            logFailure("$label failed; retrying once", firstFailure)
            block()
        }
    }

    private inline fun <T> retryCurrentRoute(label: String, block: () -> T): T {
        return runCatching(block).getOrElse { firstFailure ->
            // A deterministic protocol mismatch cannot heal on an immediate retry; let the
            // route-scoped guard move directly to the still-independent legacy route.
            if (
                firstFailure is AllAnimeCaptchaRequiredException ||
                firstFailure is CurrentRouteRateLimit ||
                isUpstreamOutage(firstFailure) ||
                currentRouteGuard.isDeterministicProtocolFailure(firstFailure)
            ) {
                throw firstFailure
            }
            logFailure("$label failed; retrying once", firstFailure)
            block()
        }
    }

    private fun currentRouteError(root: JsonObject): RouteError? {
        val errors = (root["errors"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
        if (errors.isEmpty()) return null
        val messages = errors.mapNotNull { it.string("message") }
        val codes = errors.flatMap { error ->
            val extensions = error["extensions"] as? JsonObject
            val exception = extensions?.get("exception") as? JsonObject
            listOfNotNull(extensions?.string("code"), exception?.string("code"))
        }
        val text = (messages + codes).joinToString("; ").ifBlank { "Unknown AllAnime route error" }
        return RouteError(
            message = text,
            needsCaptcha = (messages + codes).any { it.contains("NEED_CAPTCHA", true) },
            cryptoFailure = codes.any { it.startsWith("AA_CRYPTO", true) } ||
                messages.any { it.contains("AA_CRYPTO", true) },
        )
    }

    private fun stream(
        url: String,
        type: String,
        label: String,
        audio: String,
        referer: String,
    ) = StreamItem(url, type, label, audio, referer, false, null, null)

    private fun qualityLabel(source: String, quality: String?): String = listOf(
        "MKissa",
        quality?.takeIf(String::isNotBlank),
        source.takeIf(String::isNotBlank),
    ).filterNotNull().joinToString(" ")

    private fun titles(media: Media): List<String> = listOfNotNull(
        media.title.english,
        media.title.romaji,
        media.title.native,
    ).filter(String::isNotBlank).distinct()

    private fun JsonObject.string(name: String): String? = (this[name] as? JsonPrimitive)?.contentOrNull
    private fun JsonObject.int(name: String): Int? = (this[name] as? JsonPrimitive)?.intOrNull
    private fun JsonObject.boolean(name: String): Boolean = (this[name] as? JsonPrimitive)?.contentOrNull == "true"

    companion object {
        /**
         * Whether a search result could be the title asked for, as far as MAL ids can tell. Unknown on
         * either side proves nothing, so only two known, different ids rule a result out.
         */
        internal fun malIdsAgree(candidateMalId: Int?, mediaMalId: Int?): Boolean =
            candidateMalId == null || mediaMalId == null || candidateMalId == mediaMalId

        private val JSON_MEDIA_TYPE = "application/json".toMediaType()
        private const val MAX_ERROR_BODY_CHARS = 512
        private const val MAX_KEY_ATTEMPTS = 3
        private val MEDIA_URL = Regex.cached("""\.(?:m3u8|mp4)(?:[?#]|$)""", RegexOption.IGNORE_CASE)
        private val HTML_PLAYER_URL = Regex.cached("""(?:player|embed)[^/?]*\.html(?:[?#]|$)""", RegexOption.IGNORE_CASE)
        private const val SEARCH_QUERY =
            "query(\$search: SearchInput, \$limit: Int, \$page: Int, \$translationType: VaildTranslationTypeEnumType, \$countryOrigin: VaildCountryOriginEnumType) { shows(search: \$search, limit: \$limit, page: \$page, translationType: \$translationType, countryOrigin: \$countryOrigin) { edges { _id name englishName malId availableEpisodes } } }"
    }
}

internal object AllAnimeCodec {
    data class Source(
        val name: String,
        val url: String,
        val type: String,
        val quality: String?,
        val priority: Double,
        val fileExtension: String? = null,
    )

    private val hexMap = mapOf(
        "79" to 'A', "7a" to 'B', "7b" to 'C', "7c" to 'D', "7d" to 'E', "7e" to 'F', "7f" to 'G',
        "70" to 'H', "71" to 'I', "72" to 'J', "73" to 'K', "74" to 'L', "75" to 'M', "76" to 'N',
        "77" to 'O', "68" to 'P', "69" to 'Q', "6a" to 'R', "6b" to 'S', "6c" to 'T', "6d" to 'U',
        "6e" to 'V', "6f" to 'W', "60" to 'X', "61" to 'Y', "62" to 'Z', "59" to 'a', "5a" to 'b',
        "5b" to 'c', "5c" to 'd', "5d" to 'e', "5e" to 'f', "5f" to 'g', "50" to 'h', "51" to 'i',
        "52" to 'j', "53" to 'k', "54" to 'l', "55" to 'm', "56" to 'n', "57" to 'o', "48" to 'p',
        "49" to 'q', "4a" to 'r', "4b" to 's', "4c" to 't', "4d" to 'u', "4e" to 'v', "4f" to 'w',
        "40" to 'x', "41" to 'y', "42" to 'z', "08" to '0', "09" to '1', "0a" to '2', "0b" to '3',
        "0c" to '4', "0d" to '5', "0e" to '6', "0f" to '7', "00" to '8', "01" to '9', "15" to '-',
        "16" to '.', "67" to '_', "46" to '~', "02" to ':', "17" to '/', "07" to '?', "1b" to '#',
        "63" to '[', "65" to ']', "78" to '@', "19" to '!', "1c" to '$', "1e" to '&', "10" to '(',
        "11" to ')', "12" to '*', "13" to '+', "14" to ',', "03" to ';', "05" to '=', "1d" to '%',
    )

    fun decodeSourceUrl(value: String): String {
        val (payload, keyIndex) = when {
            value.startsWith("--") -> value.drop(2) to 3
            value.startsWith("#-") -> value.drop(2) to 2
            value.startsWith("##") -> value.drop(2) to 1
            value.startsWith("-#") -> value.drop(2) to 4
            value.startsWith('#') -> value.drop(1) to 0
            else -> return value
        }
        val bytes = runCatching { payload.chunked(2).map { it.toInt(16) } }.getOrNull() ?: return value
        if (bytes.isEmpty() || payload.length % 2 != 0) return value
        val mask = XOR_MASKS[keyIndex]
        return String(CharArray(bytes.size) { index -> ((bytes[index] xor mask) and 0xff).toChar() })
            .replace("/clock?", "/clock.json?")
            .let { if (it.endsWith("/clock")) "$it.json" else it }
    }

    fun isEncodedSource(value: String): Boolean =
        value.startsWith("--") || value.startsWith("#-") || value.startsWith("##") ||
            value.startsWith("-#") || value.startsWith('#')

    fun decrypt(encoded: String): JsonElement {
        val bytes = Base64Compat.decode(encoded)
        require(bytes.size > 29) { "AllAnime encrypted payload is too short" }
        val iv = bytes.copyOfRange(1, 13)
        val counter = iv + byteArrayOf(0, 0, 0, 2)
        val ciphertext = bytes.copyOfRange(13, bytes.size - 16)
        val key = MessageDigest.getInstance("SHA-256").digest(KEY_SEED.toByteArray(StandardCharsets.UTF_8))
        val cipher = Cipher.getInstance("AES/CTR/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(counter))
        val plaintext = cipher.doFinal(ciphertext).toString(StandardCharsets.UTF_8)
        return Json.parseToJsonElement(plaintext)
    }

    fun epochKey(partB: String, maskHex: String): ByteArray {
        val mask = maskHex.chunked(2).map { it.toInt(16).toByte() }
        val second = Base64Compat.decode(partB)
        require(mask.size >= 16 && second.size >= 32) { "AllAnime epoch key is invalid" }
        return ByteArray(32) { index -> (second[index].toInt() xor mask[index % mask.size].toInt()).toByte() }
    }

    fun signRequest(
        key: ByteArray,
        epoch: Int,
        buildId: String,
        queryHash: String,
        nowMs: Long,
    ): String {
        val timestamp = nowMs / REQUEST_WINDOW_MS * REQUEST_WINDOW_MS
        val iv = MessageDigest.getInstance("SHA-256")
            .digest("$epoch:$buildId:$queryHash:$timestamp".toByteArray(StandardCharsets.UTF_8))
            .copyOfRange(0, 12)
        val plaintext = """{"v":1,"ts":$timestamp,"epoch":$epoch,"buildId":"$buildId","qh":"$queryHash"}"""
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
        return Base64Compat.encode(byteArrayOf(1) + iv + encrypted)
    }

    fun decryptGcm(encoded: String, key: ByteArray): JsonElement {
        val envelope = Base64Compat.decode(encoded)
        require(envelope.size > 29 && envelope[0].toInt() == 1) { "AllAnime encrypted payload is invalid" }
        val iv = envelope.copyOfRange(1, 13)
        val encrypted = envelope.copyOfRange(13, envelope.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return Json.parseToJsonElement(cipher.doFinal(encrypted).toString(StandardCharsets.UTF_8))
    }

    fun parseSources(value: JsonElement?): List<Source> {
        val root = value as? JsonObject ?: return emptyList()
        val sourceUrls = ((root["episode"] as? JsonObject)?.get("sourceUrls") as? JsonArray)
            ?: (root["sourceUrls"] as? JsonArray)
            ?: return emptyList()
        return sourceUrls.mapNotNull { element ->
            val item = element as? JsonObject ?: return@mapNotNull null
            val url = item.primitive("sourceUrl") ?: return@mapNotNull null
            Source(
                name = item.primitive("sourceName").orEmpty(),
                url = url,
                type = item.primitive("type").orEmpty(),
                quality = item.primitive("resolutionStr"),
                priority = (item["priority"] as? JsonPrimitive)?.doubleOrNull ?: 0.0,
                fileExtension = item.primitive("fileExtenstion") ?: item.primitive("fallBack"),
            )
        }
    }

    /** Finds soft-caption rows in both decrypted episode payloads and /clock responses. */
    fun parseSubtitles(value: JsonElement?): List<SubtitleItem> {
        val result = mutableListOf<SubtitleItem>()

        fun visit(element: JsonElement?, subtitleCollection: Boolean = false) {
            when (element) {
                is JsonArray -> element.forEach { visit(it, subtitleCollection) }
                is JsonObject -> {
                    val url = SUBTITLE_URL_KEYS.firstNotNullOfOrNull { element.primitive(it) }
                    val kind = element.primitive("kind")
                        ?: element.primitive("type")
                        ?: element.primitive("trackType")
                    val extensionMatches = url?.let(SUBTITLE_URL::containsMatchIn) == true
                    val kindMatches = kind?.contains(Regex.cached("subtitle|caption", RegexOption.IGNORE_CASE)) == true
                    if (!url.isNullOrBlank() && (subtitleCollection || extensionMatches || kindMatches)) {
                        val rawLanguage = SUBTITLE_LANGUAGE_KEYS.firstNotNullOfOrNull { element.primitive(it) }
                        val rawLabel = SUBTITLE_LABEL_KEYS.firstNotNullOfOrNull { element.primitive(it) }
                        val language = subtitleLanguage(rawLanguage ?: rawLabel)
                        result += SubtitleItem(
                            url = NativeProviderParsers.decodeEntities(url),
                            label = rawLabel?.takeIf(String::isNotBlank)
                                ?: rawLanguage?.takeIf(String::isNotBlank)
                                ?: "Subtitle",
                            language = language,
                        )
                    }
                    element.forEach { (key, child) ->
                        val normalized = key.lowercase().replace(Regex.cached("[^a-z]"), "")
                        val childIsSubtitleCollection = normalized in SUBTITLE_COLLECTION_KEYS
                        visit(child, childIsSubtitleCollection)
                    }
                }
                else -> Unit
            }
        }

        visit(value)
        return result.distinctBy(SubtitleItem::url)
    }

    private fun subtitleLanguage(value: String?): String {
        val normalized = value.orEmpty().trim().lowercase().substringBefore('-').substringBefore('_')
        return when (normalized) {
            "english", "eng", "en" -> "en"
            "japanese", "jpn", "ja" -> "ja"
            "french", "fra", "fre", "fr" -> "fr"
            "german", "deu", "ger", "de" -> "de"
            "spanish", "spa", "es" -> "es"
            "portuguese", "por", "pt" -> "pt"
            "arabic", "ara", "ar" -> "ar"
            "italian", "ita", "it" -> "it"
            else -> normalized.takeIf { it.length in 2..3 } ?: "und"
        }
    }

    private fun JsonObject.primitive(name: String): String? = (this[name] as? JsonPrimitive)?.contentOrNull
    private val SUBTITLE_URL_KEYS = listOf("url", "src", "file", "link")
    private val SUBTITLE_LABEL_KEYS = listOf("label", "name", "title")
    private val SUBTITLE_LANGUAGE_KEYS = listOf("language", "lang", "srclang", "languageCode")
    private val SUBTITLE_COLLECTION_KEYS = setOf("subtitles", "subtitle", "captions", "caption")
    private val SUBTITLE_URL = Regex("\\.(?:vtt|srt|ass|ssa)(?:[?#]|$)", RegexOption.IGNORE_CASE)
    private const val KEY_SEED = "Xot36i3lK3:v1"
    private const val REQUEST_WINDOW_MS = 5 * 60 * 1000L
    private val XOR_MASKS = arrayOf(
        "allanimenews",
        "1234567890123456789",
        "1234567890123456789012345",
        "s5feqxw21",
        "feqx1",
    ).map { key -> key.fold(0) { mask, character -> mask xor character.code } }.toIntArray()
}
