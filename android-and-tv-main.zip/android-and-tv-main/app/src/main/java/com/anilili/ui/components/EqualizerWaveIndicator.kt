package com.anilili.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Per-bar timings and heights. Deliberately a table rather than arithmetic: the modulo expressions
 * this replaced produced arbitrary values (bar 4 dipped back below bar 3) that read as intentional
 * but were not. Bars are staggered so no two peak together, which is what sells the movement.
 */
private val BAR_DURATIONS_MS = intArrayOf(380, 510, 440, 610)
private val BAR_PEAKS = floatArrayOf(0.95f, 0.55f, 0.80f, 0.45f)

/**
 * Animated Equalizer Wave indicator showing bouncing audio bars for currently playing content.
 */
@Composable
fun EqualizerWaveIndicator(
    modifier: Modifier = Modifier,
    barCount: Int = 4,
    color: Color = MaterialTheme.colorScheme.primary,
    barWidth: Dp = 3.dp,
    maxHeight: Dp = 16.dp,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "equalizer_transition")

    val animValues = List(barCount) { index ->
        infiniteTransition.animateFloat(
            initialValue = 0.2f,
            targetValue = BAR_PEAKS[index % BAR_PEAKS.size],
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = BAR_DURATIONS_MS[index % BAR_DURATIONS_MS.size],
                    easing = FastOutSlowInEasing,
                ),
                repeatMode = RepeatMode.Reverse,
            ),
            label = "bar_anim_$index",
        )
    }

    // The bars grow in the draw phase, not the layout one. Reading the animation into
    // `fillMaxHeight` meant every frame recomposed this row and re-measured it, sixty times a
    // second for as long as the indicator was on screen — and its main home is the in-player
    // episode list, drawn over a video that is decoding at the same time.
    Row(
        modifier = modifier.height(maxHeight),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        animValues.forEach { anim ->
            Box(
                modifier = Modifier
                    .width(barWidth)
                    .fillMaxHeight()
                    .drawBehind {
                        val barHeight = size.height * anim.value
                        drawRoundRect(
                            color = color,
                            topLeft = Offset(0f, size.height - barHeight),
                            size = Size(size.width, barHeight),
                            cornerRadius = CornerRadius(1.5.dp.toPx()),
                        )
                    },
            )
        }
    }
}
