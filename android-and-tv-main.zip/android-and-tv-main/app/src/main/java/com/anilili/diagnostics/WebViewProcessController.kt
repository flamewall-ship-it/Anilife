package com.anilili.diagnostics

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.webkit.WebView
import com.anilili.data.device.isTelevision
import java.util.IdentityHashMap

private const val CONSTRAINED_MEMORY_CLASS_MB = 256

/** Tracks real WebView consumers and reclaims Chromium after the last one leaves a constrained TV. */
object WebViewProcessController {
    private val activeViews = IdentityHashMap<WebView, String>()
    private var terminationRequests = 0L

    fun register(view: WebView, owner: String) {
        val active = synchronized(activeViews) {
            activeViews[view] = owner
            activeViews.size
        }
        DiagnosticsLog.event(
            "webview",
            "webview.registered",
            mapOf("owner" to owner, "activeViews" to active),
        )
    }

    /**
     * Unregisters [view] and, on a low-memory TV, asks Android to terminate its renderer only when
     * no resolver, embed player, or login WebView remains. This avoids killing visible web content
     * while reclaiming the renderer Android otherwise caches after WebView.destroy().
     */
    fun release(view: WebView, owner: String) {
        val context = view.context.applicationContext
        val remaining = synchronized(activeViews) {
            activeViews.remove(view)
            activeViews.size
        }
        val shouldTerminate = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            remaining == 0 && isConstrainedTv(context)
        val terminated = if (shouldTerminate) {
            runCatching { view.webViewRenderProcess?.terminate() == true }.getOrDefault(false)
        } else {
            false
        }
        if (shouldTerminate) synchronized(activeViews) { terminationRequests++ }
        DiagnosticsLog.event(
            "webview",
            "webview.released",
            mapOf(
                "owner" to owner,
                "activeViews" to remaining,
                "terminationRequested" to shouldTerminate,
                "rendererAcceptedTermination" to terminated,
            ),
        )
    }

    fun snapshotAttributes(): Map<String, String> = synchronized(activeViews) {
        mapOf(
            "trackedWebViewCount" to activeViews.size.toString(),
            "trackedWebViewOwners" to activeViews.values.sorted().joinToString("/").ifBlank { "none" },
            "webViewRendererTerminationRequests" to terminationRequests.toString(),
        )
    }

    internal fun isConstrainedTv(context: Context): Boolean {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        return shouldTerminateRenderer(
            // Not the ui mode alone: the boxes that need a renderer killed hardest are the cheap
            // ones, and the cheap ones are exactly the ones that never report being a television.
            isTv = isTelevision(context),
            isLowRamDevice = activityManager?.isLowRamDevice == true,
            memoryClassMb = activityManager?.memoryClass,
        )
    }
}

internal fun shouldTerminateRenderer(
    isTv: Boolean,
    isLowRamDevice: Boolean,
    memoryClassMb: Int?,
): Boolean = isTv && (
    isLowRamDevice || (memoryClassMb != null && memoryClassMb <= CONSTRAINED_MEMORY_CLASS_MB)
)

/**
 * Whether a crash inside a WebView renderer takes the whole app process down with it.
 *
 * `WebViewClient.onRenderProcessGone` — the one callback that lets an app survive a dead renderer —
 * arrived in API 26. Below that the renderer is not a separate process to begin with, so there is
 * nothing to be told about and nothing to recover from: Chromium's SIGSEGV is the app's SIGSEGV.
 * It leaves no Java trace either, so no crash report and no dialog, just a process that is gone.
 *
 * Callers use this to avoid *constructing* a WebView at moments where losing the process would be
 * especially costly. It says nothing about an already-mounted one, which has survived its risky
 * startup window and costs nothing to keep.
 */
internal fun rendererCrashIsFatal(sdkInt: Int = Build.VERSION.SDK_INT): Boolean =
    sdkInt < Build.VERSION_CODES.O
